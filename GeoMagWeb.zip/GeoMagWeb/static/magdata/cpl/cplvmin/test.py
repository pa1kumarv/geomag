#!/usr/bin/env python

import pandas as pd
import os
from pathlib import Path
import matplotlib.pyplot as plt


BASE_DIR = Path(__file__).resolve().parent.parent
print(BASE_DIR)
df=pd.read_fwf("hyb20250210vmin.min", skiprows=15 )

count_row = df.shape[0]

print("count row ="+str(count_row))

#df["Time period"] = pd.to_datetime(df['DATE'] + ' ' + df['TIME'])

#df.set_index('Time period', inplace=True)

#df['1min_diff'] = df['CPLD'].diff()

#x=df['1min_diff']

#time_periods = df.index  # Extract timestamps
#diff_values = df['1min_diff']

#timestamps = df.index.tolist()  # Extract timestamps
#diff_values = df['1min_diff'].tolist()  # Extract 2-minute difference values

#print("Timestamps:", timestamps)
#print("2-Minute Difference Values:", diff_values)


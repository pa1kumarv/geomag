from django.shortcuts import render
from django.template import loader
import matplotlib
import matplotlib.pyplot as plt
import io
import urllib, base64
import pandas as pd
from django.templatetags.static import static
import datetime
import matplotlib.dates as md
from .utils import *

# Create your views here.

def home_view(request):
    loop_times = range(1, 2)
    return render(request, 'home.html', {'loop_times':loop_times})

def about_view(request):
    return render(request, 'about.html', {})

def pubs_view(request):
    return render(request, 'pubs.html', {})

def phds_view(request):
    return render(request, 'phds.html', {})

def people_view(request):
    return render(request, 'people.html', {})

def contact_view(request):
    return render(request, 'contact.html', {})

def min1plot_view(request):
    df=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df["Time period"] = pd.to_datetime(df['DATE'] + ' ' + df['TIME'])
    min1 = min(df['Time period'])
    max1 = min(df['Time period'])+datetime.timedelta(days=1)
    x=df['Time period']
    y=df['CPLD']
    y1=df['CPLH']
    y2=df['CPLZ']
    y3=df['CPLF   |']
    chart=get_plot(x,y, 'D n(T)' , 'g')
    chart1=get_plot(x,y1,'H n(T)', 'b')
    chart2=get_plot(x,y2,'Z n(T)', 'm')
    chart3=get_plot(x,y3,'F n(T)', 'r')
    context={'chart':chart,'chart1':chart1,'chart2':chart2,'chart3':chart3}
    return render(request, 'min1plot.html', context)

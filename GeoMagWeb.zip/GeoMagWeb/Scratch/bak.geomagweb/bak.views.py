from django.shortcuts import render
from django.template import loader
import matplotlib
import matplotlib.pyplot as plt
import io
import urllib, base64
import pandas as pd
from django.templatetags.static import static
import datetime
import matplotlib.dates as md
matplotlib.use('agg')
# Create your views here.

def home_view(request):
    loop_times = range(1, 2)
    return render(request, 'home.html', {'loop_times':loop_times})

def about_view(request):
    return render(request, 'about.html', {})

def pubs_view(request):
    return render(request, 'pubs.html', {})

def phds_view(request):
    return render(request, 'phds.html', {})

def people_view(request):
    return render(request, 'people.html', {})

def contact_view(request):
    return render(request, 'contact.html', {})

def min1plot_view(request):
#    file_r=static('magdata/cpl/cplvmin/cpl20250207vmin.min')
    df=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df["Time period"] = pd.to_datetime(df['DATE'] + ' ' + df['TIME'])
#    fig = plt.gcf()
    min1 = min(df['Time period'])
    #max1 = max(df['Time period'])
    max1 = min(df['Time period'])+datetime.timedelta(days=1)
    print(min1,max1)
    fig, axs = plt.subplots(figsize=(12, 4))
    axs.set(xlabel="Time", ylabel="Temperature", xlim=[min1,max1])
    plt.plot('Time period', 'CPLD', data=df, linewidth=2, color='g')
    axs.grid(True)
    xformatter = md.DateFormatter('%H:%M')
    xlocator = md.MinuteLocator(interval = 120)
    axs.xaxis.set_major_locator(xlocator)
    axs.xaxis.set_major_formatter(xformatter)
    #convert graph into dtring buffer and then we convert 64 bit code into image
    buf = io.BytesIO()
    fig.savefig(buf,format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())
    uri =  urllib.parse.quote(string)
    return render(request, 'min1plot.html', {'data':uri})

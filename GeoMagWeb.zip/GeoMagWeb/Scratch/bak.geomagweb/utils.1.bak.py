import matplotlib.pyplot as plt
import base64
from io import BytesIO
import datetime
import matplotlib.dates as md
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.io as pio
import json
import pandas as pd
from datetime import datetime, timedelta
from bokeh.plotting import figure
from bokeh.layouts import gridplot
from bokeh.embed import components
from bokeh.models import DatetimeTicker, DatetimeTickFormatter, FixedTicker, Range1d
from bokeh.models import Title







def get_graph():
    buffer=BytesIO()
    plt.savefig(buffer,format='png')
    buffer.seek(0)
    image_png=buffer.getvalue()
    graph=base64.b64encode(image_png)
    graph=graph.decode('utf-8')
    buffer.close()

    return graph

def get_mag_plot(df,stn):
    plt.switch_backend('AGG')
    x=df['Time period']
    min1=min(x)
    max1=min1+datetime.timedelta(days=1)
    fig, (ax1, ax2, ax3, ax4) = plt.subplots(4,figsize=(20, 28))
    fig.subplots_adjust(hspace=0.3)
    ax1.set_title('IMO_'+stn, pad=50, fontsize=50)
    
    cpld=df[stn+'D']
    cplh=df[stn+'H']
    cplz=df[stn+'Z']
    cplf=df[stn+'F   |']
    ax1.plot(x,cpld,linewidth=2, color='g')
    ax1.set_ylabel("D (nT)", fontsize = 25)
    ax2.plot(x,cplh,linewidth=2, color='b')
    ax2.set_ylabel("H (nT)", fontsize = 25)
    ax3.plot(x,cplz,linewidth=2, color='m')
    ax3.set_ylabel("Z (nT)", fontsize = 25)
    ax4.plot(x,cplf,linewidth=2, color='r')
    ax4.set_ylabel("F (nT)", fontsize = 25)
    xformatter = md.DateFormatter('%H:%M')
    xlocator = md.MinuteLocator(interval = 180)

    for ax in fig.get_axes():
        ax.set(xlabel="UT (Hours)", xlim=[min1,max1])
        ax.set_xlabel("UT (Hours)",fontsize = 25)
        ax.xaxis.set_tick_params( labelsize = 20) 
        ax.yaxis.set_tick_params( labelsize = 20) 
        ax.grid(True)
        ax.minorticks_on()
        ax.grid(which='minor', linestyle='-', linewidth='0.5', color='gray')
        ax.xaxis.set_minor_locator(md.HourLocator(byhour=None, interval=1, tz=None))
        ax.xaxis.set_major_locator(xlocator)
        ax.xaxis.set_major_formatter(xformatter)

    graph=get_graph()
    return graph

def get_diff_plot(df,df_hyb,stn1,stn2):

    df['dmin_diff'] = df[stn1+'D'].diff()
    df['hmin_diff'] = df[stn1+'H'].diff()
    df['zmin_diff'] = df[stn1+'Z'].diff()
    df['fmin_diff'] = df[stn1+'F   |'].diff()

    dx=df.index.tolist()
    min1=min(dx)
    max1=min1+timedelta(days=1)

    dd=df['dmin_diff'].tolist()
    dh=df['hmin_diff'].tolist()
    dz=df['zmin_diff'].tolist()
    df=df['fmin_diff'].tolist()

    df_hyb['dmin_diff'] = df_hyb[stn2+'D'].diff()
    df_hyb['hmin_diff'] = df_hyb[stn2+'H'].diff()
    df_hyb['zmin_diff'] = df_hyb[stn2+'Z'].diff()
    df_hyb['fmin_diff'] = df_hyb[stn2+'F   |'].diff()

    ddh=df_hyb['dmin_diff'].tolist()
    dhh=df_hyb['hmin_diff'].tolist()
    dzh=df_hyb['zmin_diff'].tolist()
    dfh=df_hyb['fmin_diff'].tolist()

    rows, cols = 4, 1
    fig =  make_subplots(rows=rows, cols=cols)
     # Add traces (plots) to different rows
    fig.add_trace(go.Scattergl(x=dx, y=dd, mode='lines', name=stn1+"D"), row=1, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=ddh, mode='lines', name=stn2+"D"), row=1, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=dh, mode='lines', name=stn1+"H"), row=2, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=dhh, mode='lines', name=stn2+"H"), row=2, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=dz, mode='lines', name=stn1+"Z"), row=3, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=dzh, mode='lines', name=stn2+"Z"), row=3, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=df, mode='lines', name=stn1+"F"), row=4, col=1)
    fig.add_trace(go.Scattergl(x=dx, y=dfh, mode='lines', name=stn2+"F"), row=4, col=1)

     # Adjust layout
    for i in range(1,5):
        fig.update_xaxes(range=[min1, max1],title_text="UT (Hours)",minor=dict(showgrid=False,gridcolor='LightGray',griddash='dashdot'),title_standoff=0, row=i, col=1) 
        fig.update_xaxes(showline = True, linecolor = 'black', gridcolor='Gray',linewidth = 1, row = i, col = 1, mirror = True)
        fig.update_yaxes(showline = True, linecolor = 'black', linewidth = 1, row = i, col = 1, mirror = True)

    y_titles=['D','H','Z','F']

    for i in range(len(y_titles)+1):
        fig.update_yaxes(title_text=y_titles[i-1]+"(nT)", gridcolor='Gray',title_standoff=0, row=i, col=1)

    fig.update_layout(
    annotations=[
        dict(text="IMO_"+stn1+"_"+stn2, x=0.5, y=1.05, xref="paper", yref="paper", showarrow=False, font=dict(size=16)),

         ]
     )

    fig.update_layout(height=1000, width=800)

    graph_json1 = json.dumps(pio.to_json(fig)) 
    return graph_json1 

     



def get_histo_plot(df,df_hyb,stn1,stn2):
    plt.switch_backend('AGG')
    
    df['dmin_diff'] = df[stn1+'D'].diff()
    df['hmin_diff'] = df[stn1+'H'].diff()
    df['zmin_diff'] = df[stn1+'Z'].diff()
    df['fmin_diff'] = df[stn1+'F   |'].diff()
    
    df_hyb['dmin_diff'] = df_hyb[stn2+'D'].diff()
    df_hyb['hmin_diff'] = df_hyb[stn2+'H'].diff()
    df_hyb['zmin_diff'] = df_hyb[stn2+'Z'].diff()
    df_hyb['fmin_diff'] = df_hyb[stn2+'F   |'].diff()

    dx=df.index.tolist()
    min1=min(dx)
    max1=min1+datetime.timedelta(days=1)

    dd=df['dmin_diff'].tolist()
    dh=df['hmin_diff'].tolist()
    dz=df['zmin_diff'].tolist()
    df=df['fmin_diff'].tolist()
    
    ddh=df_hyb['dmin_diff'].tolist()
    dhh=df_hyb['hmin_diff'].tolist()
    dzh=df_hyb['zmin_diff'].tolist()
    dfh=df_hyb['fmin_diff'].tolist()

    fig, (ax1,ax2,ax3,ax4) = plt.subplots(4,figsize=(20, 28))

    ax1.plot(dx,dd, linewidth="10", color='g')
    ax1.plot(dx,ddh,linewidth="2",  color='y')

    ax2.plot(dx,dh, linewidth="10",color='b')
    ax2.plot(dx,dhh, linewidth="2", color='y')

    ax3.plot(dx,dz, linewidth="10", color='m')
    ax3.plot(dx,dzh, linewidth="2", color='y')

    ax4.plot(dx,df, linewidth="10", color='r')
    ax4.plot(dx,dfh, linewidth="2",  color='y')

    xformatter = md.DateFormatter('%H:%M')
    xlocator = md.MinuteLocator(interval = 180)

    for ax in fig.get_axes():
        ax.set(xlabel="UT (Hours)", xlim=[min1,max1])
        ax.set_xlabel("UT (Hours)",fontsize = 25)
        ax.xaxis.set_tick_params( labelsize = 20)
        ax.yaxis.set_tick_params( labelsize = 20)
        ax.grid(True)
        ax.minorticks_on()
        ax.grid(which='minor', linestyle='-', linewidth='0.5', color='gray')
        ax.xaxis.set_minor_locator(md.HourLocator(byhour=None, interval=1, tz=None))
        ax.xaxis.set_major_locator(xlocator)
        ax.xaxis.set_major_formatter(xformatter)


    graph=get_graph()
    return graph


def get_bokeh_plot(df,stn):
    x=df['Time period']
    min1=df['Time period'].min()
    max1=min1+timedelta(days=1)

    # set min and max date times for plotting
    x_min = df['Time period'].min() - pd.Timedelta(days=0)
    x_max = df['Time period'].max() + pd.Timedelta(days=1)

    cpld=df[stn+'D']
    cplh=df[stn+'H']
    cplz=df[stn+'Z']
    cplf=df[stn+'F   |']

    time_range = [min1 + timedelta(hours=i) for i in range(24)]

    plot1 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="D (nT)", width=700, height=220, x_range=(min1, max1))
    plot1.line(x, cpld, line_width=2, legend_label=stn+"D", color="blue")
    # Add a title with specific settings
    title = Title()
    title.text = "IMO_"+stn
    title.text_font_size = "15pt"
    title.text_color = "black"
    title.align = "center"  # Correct alignment
    title.vertical_align = 'top'
    plot1.title = title
#    plot1.margin = (40, 10, 10, 10)

    plot2 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="H (nT)", width=700, height=220, x_range=(min1, max1))
    plot2.line(x, cplh, line_width=2, legend_label=stn+"H",color="green")

    plot3 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="Z (nT)", width=700, height=220, x_range=(min1, max1))
    plot3.line(x, cplz, line_width=2, legend_label=stn+"Z", color="red")

    plot4 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="F (nT)", width=700, height=220, x_range=(min1, max1))
    plot4.line(x, cplf, line_width=2, legend_label=stn+"F", color="purple")

    #figures = [figure(x_axis_type="datetime",x_axis_label="UT (Hours)", width=700, height=220  ) for i in range(4)]

    for p in [plot1,plot2,plot3,plot4]:   
    # Set x-axis ticker to every 2 hours
       tick_values = [min1 + timedelta(hours=2 * i) for i in range(13)]
       p.xaxis.ticker = FixedTicker(ticks=[t.timestamp() * 1000 for t in tick_values])
       p.xaxis.formatter = DatetimeTickFormatter(hours=["%H:%M"])
    # Make the background transparent (0.0 is fully transparent)
       p.legend.background_fill_alpha = 0.0
    # Set x-axis label and customize font
       p.xaxis.axis_label_text_font_size = "10pt"
       p.xaxis.axis_label_text_font_style = "bold"
       p.xaxis.axis_label_text_font = "Times New Roman"

    # Set y-axis label and customize font
       p.yaxis.axis_label_text_font_size = "10pt"
       p.yaxis.axis_label_text_font_style = "bold"
       p.yaxis.axis_label_text_font = "Times New Roman"

    # Add line plot to each figure
    #   if i == 0:
    #       p.line(x, cpld, line_width=2, legend_label=stn+"D", color="blue" )
    #       p.yaxis.axis_label = f"D (nT)"
    #   elif i == 1:
    #       p.line(x, cplh, line_width=2, legend_label=stn+"H", color="green")
    #       p.yaxis.axis_label = f"H (nT)"
    #   elif i == 2:
    #       p.line(x, cplz, line_width=2, legend_label=stn+"Z", color="red")
    #       p.yaxis.axis_label = f"Z (nT)"
    #   else:
    #       p.line(x, cplf, line_width=2, legend_label=stn+"F", color="purple")
    #       p.yaxis.axis_label = f"F (nT)"

       # Arrange subfigures in a grid layout
    grid = gridplot([[plot1], [plot2], [plot3], [plot4]])

     # Embed the plot into the Django template
    script, div = components(grid)
       
    return script,div






def get_plotly_plot(df,stn):
    x=df['Time period']
    min1=min(x)
    max1=min1+datetime.timedelta(days=1)

    cpld=df[stn+'D']
    cplh=df[stn+'H']
    cplz=df[stn+'Z']
    cplf=df[stn+'F   |']
   # fig = make_subplots(rows=4, cols=1, row_heights=[0.25, 0.25, 0.25, 0.25], vertical_spacing=0.07)
    rows, cols = 4, 1
    fig = make_subplots(rows=rows, cols=cols)
     # Add traces (plots) to different rows
    fig.add_trace(go.Scattergl(x=x, y=cpld, mode='lines', name=stn+"D"), row=1, col=1)
    fig.add_trace(go.Scattergl(x=x, y=cplh, mode='lines', name=stn+"H"), row=2, col=1)
    fig.add_trace(go.Scattergl(x=x, y=cplz, mode='lines', name=stn+"Z"), row=3, col=1)
    fig.add_trace(go.Scattergl(x=x, y=cplf, mode='lines', name=stn+"F"), row=4, col=1)

     # Adjust layout
    for i in range(1,5):
        fig.update_xaxes(range=[min1, max1],title_text="UT (Hours)",minor=dict(showgrid=True,gridcolor='LightGray',griddash='dashdot'),title_standoff=0, row=i, col=1) 
        fig.update_xaxes(showline = True, linecolor = 'black', gridcolor='Gray',linewidth = 1, row = i, col = 1, mirror = True)
        fig.update_yaxes(showline = True, linecolor = 'black', linewidth = 1, row = i, col = 1, mirror = True)

    y_titles=['D','H','Z','F']

    for i in range(len(y_titles)+1):
        fig.update_yaxes(title_text=y_titles[i-1]+"(nT)", gridcolor='Gray',title_standoff=0, row=i, col=1)
  
    fig.update_layout(
    annotations=[
        dict(text="IMO_"+stn, x=0.5, y=1.05, xref="paper", yref="paper", showarrow=False, font=dict(size=16)),  

         ]
     )


    # Define solid borders for each subplot

    fig.update_layout(height=1000, width=800)


    graph_json = json.dumps(pio.to_json(fig)) 
    return graph_json 
    


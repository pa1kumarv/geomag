import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Define start time for gridlines
min1 = pd.Timestamp("2024-02-14 00:00:00")

# Create a subplot figure (e.g., 2 rows, 2 columns)
rows, cols = 2, 2  # Adjust as needed
fig = make_subplots(rows=rows, cols=cols, shared_xaxes=True, shared_yaxes=True)

# Generate minor grid lines for each subplot
minor_grid_lines = []
time_stamps = pd.date_range(min1, periods=24, freq="H")  # 1-hour minor grid

# Loop through all subplots
for row in range(1, rows + 1):
    for col in range(1, cols + 1):
        subplot_idx = (row - 1) * cols + col  # Calculate subplot index
        
        for time in time_stamps:
            minor_grid_lines.append(
                dict(
                    type="line",
                    x0=time, x1=time,
                    y0=0, y1=1,
                    xref=f"x{subplot_idx}",  # Reference subplot's x-axis
                    yref=f"y{subplot_idx}",  # Reference subplot's y-axis (ensures gridlines stay within)
                    line=dict(color="lightblue", width=0.5, dash="dot")
                )
            )

# Update layout with minor grid lines
fig.update_layout(shapes=minor_grid_lines)

# Show the figure
fig.show()


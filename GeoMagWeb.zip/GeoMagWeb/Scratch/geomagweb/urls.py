from django.urls import path, include, re_path
from geomagweb import views

urlpatterns = [
    re_path(r'^$', views.home_view, name='home'),
    re_path(r'^home', views.home_view, name='home'),
    re_path(r'^about', views.about_view, name='about'),
    re_path(r'^pubs', views.pubs_view, name='pubs'),
    re_path(r'^phds', views.phds_view, name='phds'),
    re_path(r'^people', views.people_view, name='people'),
    re_path(r'^contact', views.contact_view, name='contact'),
    re_path(r'^min1plot', views.bokeh_1minplot, name='min1plot'),
    re_path(r'^sec1plot', views.bokeh_1secplot, name='sec1plot'),
    re_path(r'^min1diff', views.bokeh_1mindiff, name='min1diff'),
    re_path(r'^sec1diff', views.bokeh_1secdiff, name='sec1diff'),
    re_path(r'^check-status/', views.check_status, name='check-status'),
]

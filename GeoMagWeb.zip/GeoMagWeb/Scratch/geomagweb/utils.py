import matplotlib.pyplot as plt
import base64
from io import BytesIO
import datetime
import matplotlib.dates as md
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.io as pio
import json
import pandas as pd
from datetime import datetime, timedelta
from bokeh.plotting import figure
from bokeh.layouts import gridplot
from bokeh.embed import components
from bokeh.models import DatetimeTicker, DatetimeTickFormatter, FixedTicker, Range1d
from bokeh.models import Title

def get_bokeh_plot(df,stn):
    x=df['Time period']
    min1=df['Time period'].min()
    max1=min1+timedelta(days=1)

    # set min and max date times for plotting
    x_min = df['Time period'].min() - pd.Timedelta(days=0)
    x_max = df['Time period'].max() + pd.Timedelta(days=1)

    cpld=df[stn+'D']
    cplh=df[stn+'H']
    cplz=df[stn+'Z']
    cplf=df[stn+'F   |']

    time_range = [min1 + timedelta(hours=i) for i in range(24)]

    plot1 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="D (nT)", width=700, height=220, x_range=(min1, max1))
    plot1.line(x, cpld, line_width=2, legend_label=stn+"D", color="blue")
    # Add a title with specific settings
    title = Title()
    title.text = "IMO_"+stn
    title.text_font_size = "15pt"
    title.text_color = "black"
    title.align = "center"  # Correct alignment
    title.vertical_align = 'top'
    plot1.title = title
#    plot1.margin = (40, 10, 10, 10)

    plot2 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="H (nT)", width=700, height=220, x_range=(min1, max1))
    plot2.line(x, cplh, line_width=2, legend_label=stn+"H",color="green")

    plot3 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="Z (nT)", width=700, height=220, x_range=(min1, max1))
    plot3.line(x, cplz, line_width=2, legend_label=stn+"Z", color="red")

    plot4 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="F (nT)", width=700, height=220, x_range=(min1, max1))
    plot4.line(x, cplf, line_width=2, legend_label=stn+"F", color="purple")

    #figures = [figure(x_axis_type="datetime",x_axis_label="UT (Hours)", width=700, height=220  ) for i in range(4)]

    for p in [plot1,plot2,plot3,plot4]:   
    # Set x-axis ticker to every 2 hours
       tick_values = [min1 + timedelta(hours=2 * i) for i in range(13)]
       p.xaxis.ticker = FixedTicker(ticks=[t.timestamp() * 1000 for t in tick_values])
       p.xaxis.formatter = DatetimeTickFormatter(hours=["%H:%M"])
    # Make the background transparent (0.0 is fully transparent)
       p.legend.background_fill_alpha = 0.0
    # Set x-axis label and customize font
       p.xaxis.axis_label_text_font_size = "10pt"
       p.xaxis.axis_label_text_font_style = "bold"
       p.xaxis.axis_label_text_font = "Times New Roman"

    # Set y-axis label and customize font
       p.yaxis.axis_label_text_font_size = "10pt"
       p.yaxis.axis_label_text_font_style = "bold"
       p.yaxis.axis_label_text_font = "Times New Roman"


    # Arrange subfigures in a grid layout
    grid = gridplot([[plot1], [plot2], [plot3], [plot4]])

     # Embed the plot into the Django template
    script, div = components(grid)
       
    return script,div

def get_diff_plot(df1,stn1):

    

    df1['dmin_diff'] = df1[stn1+'D'].diff()
    df1['hmin_diff'] = df1[stn1+'H'].diff()
    df1['zmin_diff'] = df1[stn1+'Z'].diff()
    df1['fmin_diff'] = df1[stn1+'F   |'].diff()

    dx=df1.index.tolist()
    min1=min(dx)
    max1=min1+timedelta(days=1)

    dhd=df1['dmin_diff'].tolist()
    dhh=df1['hmin_diff'].tolist()
    dhz=df1['zmin_diff'].tolist()
    dhf=df1['fmin_diff'].tolist()

    plot1 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="D (nT)", width=700, height=220, x_range=(min1, max1))
    plot1.line(dx, dhd, line_width=2, color="blue",legend_label=stn1+"D")

    # Add a title with specific settings
    title = Title()
    title.text = "IMO_"+stn1+"_diff"
    title.text_font_size = "15pt"
    title.text_color = "black"
    title.align = "center"  # Correct alignment
    title.vertical_align = 'top'
    plot1.title = title

    # Set x-axis ticker to every 2 hours
    tick_values = [min1 + timedelta(hours=2 * i) for i in range(13)]  # Every 2 hours

    plot2 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="H (nT)", width=700, height=220, x_range=(min1, max1))
    plot2.line(dx, dhh, line_width=2, color="green",legend_label=stn1+"H")

    plot3 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="Z (nT)", width=700, height=220, x_range=(min1, max1))
    plot3.line(dx, dhz, line_width=2, color="red",legend_label=stn1+"Z")

    plot4 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="F (nT)", width=700, height=220, x_range=(min1, max1))
    plot4.line(dx, dhf, line_width=2, color="purple",legend_label=stn1+"F")


    i=0
    for plot in [plot1,plot2,plot3,plot4]:
       leg = plot.legend[0]
       plot.add_layout(leg,'right')

       plot.xaxis.ticker = FixedTicker(ticks=[t.timestamp() * 1000 for t in tick_values])  # Convert to milliseconds
       plot.xaxis.formatter = DatetimeTickFormatter(hours=["%H:%M"])
       # Make the background transparent (0.0 is fully transparent)
       plot.legend.background_fill_alpha = 0.0
       # Set x-axis label and customize font
       plot.xaxis.axis_label_text_font_size = "10pt"
       plot.xaxis.axis_label_text_font_style = "bold"
       plot.xaxis.axis_label_text_font = "Times New Roman"

       # Set y-axis label and customize font
       plot.yaxis.axis_label_text_font_size = "10pt"
       plot.yaxis.axis_label_text_font_style = "bold"
       plot.yaxis.axis_label_text_font = "Times New Roman"

       i=i+1

    # Arrange plots in a grid layout
    grid = gridplot([[plot1], [plot2],[plot3],[plot4]])

    # Embed the plot into the Django template
    script, div = components(grid)

    return script,div





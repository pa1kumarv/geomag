from django.shortcuts import render
from django.template import loader
from django.templatetags.static import static
from django.conf import settings 
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
import matplotlib
import matplotlib.pyplot as plt
import io
import os
import urllib, base64
import pandas as pd
from datetime import datetime, timedelta
import matplotlib.dates as md
from bokeh.plotting import figure, curdoc
from bokeh.layouts import gridplot, column
from bokeh.embed import components
from bokeh.models import DatetimeTicker, DatetimeTickFormatter, FixedTicker, Div
from .utils import *
import threading

# Create your views here.

def home_view(request):
    loop_times = range(1, 2)
    return render(request, 'home.html', {'loop_times':loop_times})

def about_view(request):
    return render(request, 'about.html', {})

def pubs_view(request):
    return render(request, 'pubs.html', {})

def phds_view(request):
    return render(request, 'phds.html', {})

def people_view(request):
    return render(request, 'people.html', {})

def contact_view(request):
    return render(request, 'contact.html', {})



def min1plot_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvmin/hyb20250207vmin.min", skiprows=15 )

    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])

    chart1=get_plotly_plot(df_hyb,'HYB')
    chart2=get_plotly_plot(df_cpl,'CPL')

    context = {'chart1':chart1,'chart2':chart2}
    return render(request, 'min1plot.html', context)

def sec1plot_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvsec/cpl20250207vsec.sec", skiprows=15 )
    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvmin/hyb20250207vmin.min", skiprows=15 )

    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])

    chart1=get_plotly_plot(df_hyb,'HYB')
    chart2=get_plotly_plot(df_cpl,'CPL')

    context = {'chart1':chart1,'chart2':chart2}
#    context = {'chart2':chart2}
    return render(request, 'sec1plot.html', context)


def min1plot_mat_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvmin/hyb20250207vmin.min", skiprows=15 )

    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])

    chart1=get_mag_plot(df_cpl,'CPL')
#    chart2=get_mag_plot(df_hyb,'HYB')

#    context = {'chart1':chart1,'chart2':chart2}
    return render(request, 'min1plot.html', {'hist1':chart1})

def min1diff_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_cpl.set_index('Time period', inplace=True)

    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvmin/hyb20250207vmin.min", skiprows=15 )
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
    df_hyb.set_index('Time period', inplace=True)

    hist1 = get_diff_plot(df_cpl, df_hyb, 'CPL','HYB')

    return render(request, 'min1diff.html', {'hist1':hist1})

def sec1diff_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvsec/cpl20250207vsec.sec", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_cpl.set_index('Time period', inplace=True)

    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvsec/hyb20250207vsec.sec", skiprows=15 )
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
    df_hyb.set_index('Time period', inplace=True)

    hist2 = get_diff_plot(df_cpl, df_hyb, 'CPL','HYB')

    return render(request, 'sec1diff.html', {'hist2':hist2})


def sec1diffbokeh(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvsec/cpl20250207vsec.sec", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_cpl.set_index('Time period', inplace=True)

    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvsec/hyb20250207vsec.sec", skiprows=15 )
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
    df_hyb.set_index('Time period', inplace=True)

    df = df_cpl
    stn1="CPL"
    stn2="HYB"

    df['dmin_diff'] = df[stn1+'D'].diff()
    df['hmin_diff'] = df[stn1+'H'].diff()
    df['zmin_diff'] = df[stn1+'Z'].diff()
    df['fmin_diff'] = df[stn1+'F   |'].diff()

    dx=df.index.tolist()
    min1=min(dx)
    max1=min1+timedelta(days=1)

    dd=df['dmin_diff'].tolist()
    dh=df['hmin_diff'].tolist()
    dz=df['zmin_diff'].tolist()
    df=df['fmin_diff'].tolist()

    df_hyb['dmin_diff'] = df_hyb[stn2+'D'].diff()
    df_hyb['hmin_diff'] = df_hyb[stn2+'H'].diff()
    df_hyb['zmin_diff'] = df_hyb[stn2+'Z'].diff()
    df_hyb['fmin_diff'] = df_hyb[stn2+'F   |'].diff()

    ddh=df_hyb['dmin_diff'].tolist()
    dhh=df_hyb['hmin_diff'].tolist()
    dzh=df_hyb['zmin_diff'].tolist()
    dfh=df_hyb['fmin_diff'].tolist()

    plot1 = figure(title="Line Chart", width=400, height=300,  x_range=(min1, max1) )
    plot1.line(dx, dd, line_width=2, color="blue")
    plot1.line(dx, ddh, line_width=2, color="red")
    # Explicitly set range bounds to prevent extra boundary space
#    plot1.x_range.bounds = (min1, max1)
#    plot1.y_range.bounds = (min(dd), max(dd))
    # Disable automatic range padding
#    plot1.x_range.range_padding = 0  # Ensures no extra boundary
#    plot1.y_range.range_padding = 0  # Ensures no extra boundary
#    plot1.x_range.start = min1
#    plot1.x_range.end = max1
#    plot1.y_range.start = min(dd)
#    plot1.y_range.end = max(dd)
  
    plot2 = figure(width=400, height=300)
    plot2.line(dx, dh, line_width=2, color="blue")
    plot2.line(dx, dhh, line_width=2, color="red")

    # Arrange plots in a grid layout
    grid = gridplot([[plot1, plot2]])

    # Embed the plot into the Django template
    script, div = components(grid)
    
    return render(request, "sec1diffbokeh.html", {"script": script, "div": div})

def min1histo_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_cpl.set_index('Time period', inplace=True)

    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvmin/hyb20250207vmin.min", skiprows=15 )
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
    df_hyb.set_index('Time period', inplace=True)

    hist1 = get_histo_plot(df_cpl, df_hyb, 'CPL','HYB')

    return render(request, 'min1hist.html', {'hist1':hist1})

def min2plot_view(request):
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvmin/cpl20250207vmin.min", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    chart1=get_plotly_plot(df_cpl,'CPL')
    return render(request, 'min2plot.html', {'hist1':chart1})

def bokeh_chart(request):
    # Create a Bokeh figure
    df_cpl=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/cpl/cplvsec/cpl20250207vsec.sec", skiprows=15 )
    df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
    df_cpl.set_index('Time period', inplace=True)

    df_hyb=pd.read_fwf("/home/pavan/DjangoWork/geomag/static/magdata/hyb/hybvsec/hyb20250207vsec.sec", skiprows=15 )
    df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
    df_hyb.set_index('Time period', inplace=True)

    df = df_cpl
    stn1="CPL"
    stn2="HYB"

    df['dmin_diff'] = df[stn1+'D'].diff()
    df['hmin_diff'] = df[stn1+'H'].diff()
    df['zmin_diff'] = df[stn1+'Z'].diff()
    df['fmin_diff'] = df[stn1+'F   |'].diff()

    dt1=df.index.tolist()
    min1=min(dt1)
    max1=min1+timedelta(days=1)
    dx1 = [min1 + timedelta(hours=3 * i) for i in range(10)]
    dx=dt1

    dd=df['dmin_diff'].tolist()
    dh=df['hmin_diff'].tolist()
    dz=df['zmin_diff'].tolist()
    df=df['fmin_diff'].tolist()

    df_hyb['dmin_diff'] = df_hyb[stn2+'D'].diff()
    df_hyb['hmin_diff'] = df_hyb[stn2+'H'].diff()
    df_hyb['zmin_diff'] = df_hyb[stn2+'Z'].diff()
    df_hyb['fmin_diff'] = df_hyb[stn2+'F   |'].diff()

    ddh=df_hyb['dmin_diff'].tolist()
    dhh=df_hyb['hmin_diff'].tolist()
    dzh=df_hyb['zmin_diff'].tolist()
    dfh=df_hyb['fmin_diff'].tolist()

    plot1 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="D (nT)",title="Line Chart", width=500, height=200, x_range=(min1, max1))
    plot1.line(dx, dd, line_width=2, color="blue")
    plot1.line(dx, ddh, line_width=2, color="red")
    # Set x-axis ticker to every 2 hours
    tick_values = [min1 + timedelta(hours=2 * i) for i in range(13)]  # Every 2 hours

    plot2 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="H (nT)", width=500, height=200, x_range=(min1, max1))
    plot2.line(dx, dh, line_width=2, color="blue")
    plot2.line(dx, dhh, line_width=2, color="red")
    
    plot3 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="Z (nT)", width=500, height=200, x_range=(min1, max1))
    plot3.line(dx, dz, line_width=2, color="blue")
    plot3.line(dx, dzh, line_width=2, color="red")
    
    plot4 = figure(x_axis_type="datetime", x_axis_label="UT (Hours)", y_axis_label="F (nT)", width=500, height=200, x_range=(min1, max1))
    plot4.line(dx, df, line_width=2, color="blue")
    plot4.line(dx, dfh, line_width=2, color="red")

    for plot in [plot1,plot2,plot3,plot4]:
        plot.xaxis.ticker = FixedTicker(ticks=[t.timestamp() * 1000 for t in tick_values])  # Convert to milliseconds
        plot.xaxis.formatter = DatetimeTickFormatter(hours=["%H:%M"])
        plot.yaxis.axis_label_text_font_style="bold"
        plot.xaxis.axis_label_text_font_style="bold"

    # Arrange plots in a grid layout
    grid = gridplot([[plot1], [plot2],[plot3],[plot4]])

    # Embed the plot into the Django template
    script, div = components(grid)


    # Pass the script and div to the template
    return render(request, "bokeh_chart.html", {"script": script, "div": div})


def bokeh_1minplot(request):
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_date1 = datetime.now().strftime("%d-%m-%Y")
    current_date2 = datetime.now().strftime("%Y%m%d")

    if request.method=='POST':
       date_val=request.POST['selday']
       current_date=date_val 
       current_date1 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%d-%m-%Y")
       current_date2 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%Y%m%d")
       print("date_value "+date_val+"current_date :"+current_date+" 1:"+current_date1+" 2:"+current_date2)


    cpl_min_file=os.path.join(settings.MAGDATA_ROOT,"cpl/cplvmin/cpl"+current_date2+"vmin.min")
    hyb_min_file=os.path.join(settings.MAGDATA_ROOT,"hyb/hybvmin/hyb"+current_date2+"vmin.min")

    # Check if the file exists
    if os.path.exists(cpl_min_file):
       df_cpl=pd.read_fwf(cpl_min_file, skiprows=15 )
       df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
       script2,div2=get_bokeh_plot(df_cpl,'CPL')

    else:
        script2=""
        div2="<center><h5 style=\"margin:40 50 50 0;font-weight:bold;align:center; \"> IMO_CPL</h5></center><br><center><br> \
        <div class=\"alert alert-warning\"><strong>IMO_CPL :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong></center> </div>"
        print(cpl_min_file+": The file does not exist.")

    if os.path.exists(hyb_min_file):
       df_hyb=pd.read_fwf(hyb_min_file, skiprows=15 )
       df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
       script1,div1=get_bokeh_plot(df_hyb,'HYB')

    else:
        script1=""
        div1="<center><h5 style=\"margin:40 50 50 0;font-weight:bold;align:center; \"> IMO_HYB</h5></center><br><br><center> \
        <div class=\"alert alert-warning\"><strong>IMO_HYB :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong> </div></center>"
        print(hyb_min_file+": The file does not exist.")

    context = {'script1':script1,'div1':div1,'script2':script2,'div2':div2,'today':current_date,'today1':current_date1}
    return render(request, 'min1plot.html', context)

def bokeh_1secplot(request):
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_date1 = datetime.now().strftime("%d-%m-%Y")
    current_date2 = datetime.now().strftime("%Y%m%d")

    if request.method=='POST':
       date_val=request.POST['selday']
       current_date=date_val 
       current_date1 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%d-%m-%Y")
       current_date2 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%Y%m%d")
       print("date_value "+date_val+"current_date :"+current_date+" 1:"+current_date1+" 2:"+current_date2)

    cpl_sec_file=os.path.join(settings.MAGDATA_ROOT,"cpl/cplvsec/cpl"+current_date2+"vsec.sec")
    hyb_sec_file=os.path.join(settings.MAGDATA_ROOT,"hyb/hybvsec/hyb"+current_date2+"vsec.sec")

    # Check if the CPL file exists
    if os.path.exists(cpl_sec_file):
       df_cpl=pd.read_fwf(cpl_sec_file, skiprows=15 )
       df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
       script2,div2=get_bokeh_plot(df_cpl,'CPL')
    else:
        script2=""
        div2="<center><h5 style=\"margin:40 50 50 0;font-weight:bold;align:center; \"> IMO_CPL</h5></center><br><center><br> \
        <div class=\"alert alert-warning\"><strong>IMO_CPL :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong></center> </div>"
        print(cpl_sec_file+": The file does not exist.")

    # Check if the HYB file exists
    if os.path.exists(hyb_sec_file):
       df_hyb=pd.read_fwf(hyb_sec_file, skiprows=15 )
       df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
       script1,div1=get_bokeh_plot(df_hyb,'HYB')

    else:
        script1=""
        div1="<center><h5 style=\"margin:40 50 50 0;font-weight:bold;align:center; \"> IMO_HYB</h5></center><br><br><center> \
        <div class=\"alert alert-warning\"><strong>IMO_HYB :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong> </div></center>"
        print(hyb_sec_file+": The file does not exist.")

    context = {'script1':script1,'div1':div1,'script2':script2,'div2':div2,'today':current_date,'today1':current_date1}
    return render(request, 'sec1plot.html', context)

@csrf_exempt
def bokeh_1mindiff(request):
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_date1 = datetime.now().strftime("%d-%m-%Y")
    current_date2 = datetime.now().strftime("%Y%m%d")

    if request.method=='POST':
       date_val=request.POST['selday']
       current_date=date_val
       current_date1 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%d-%m-%Y")
       current_date2 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%Y%m%d")
       print("date_value "+date_val+"current_date :"+current_date+" 1:"+current_date1+" 2:"+current_date2)

    cpl_min_diff_file=os.path.join(settings.MAGDATA_ROOT,"cpl/cplvmin/cpl"+current_date2+"vmin.min")
    hyb_min_diff_file=os.path.join(settings.MAGDATA_ROOT,"hyb/hybvmin/hyb"+current_date2+"vmin.min")

    div_err="<br><br><br><br>"

    # Check if the CPL file exists
    if os.path.exists(cpl_min_diff_file):
       df_cpl=pd.read_fwf(cpl_min_diff_file, skiprows=15 )
       df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
       df_cpl.set_index('Time period', inplace=True)
       script2, div2=get_diff_plot(df_cpl,'CPL')
       fcpl=True
       len_cpl=df_cpl.shape[0]

    else:
       fcpl=False
       script2=""
       div2=div_err+" <div class=\"alert alert-warning\"><strong>IMO_CPL :"+current_date1+" </strong> <br>  \
       <strong>Warning! Data Not Available.... </strong></center> </div>" 

    # Check if the HYB file exists
    if os.path.exists(hyb_min_diff_file):
       df_hyb=pd.read_fwf(hyb_min_diff_file, skiprows=15 )
       df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
       df_hyb.set_index('Time period', inplace=True)
       fhyb=True
       len_hyb=df_hyb.shape[0]
       script1, div1=get_diff_plot(df_hyb,'HYB')
    else:
       fhyb=False
       script1=""
       div1=div_err+" <div class=\"alert alert-warning\"><strong>IMO_HYB :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong></center> </div>" 
    # Pass the script and div to the template
    context={"script1": script1, "div1": div1,"script2": script2, "div2": div2,'today':current_date,'today1':current_date1}

    return render(request, "min1diff.html", context)

def bokeh_1secdiff(request):
    # Create a "Please Wait" messag
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_date1 = datetime.now().strftime("%d-%m-%Y")
    current_date2 = datetime.now().strftime("%Y%m%d")

    if request.method=='POST':
       messages.info(request, "Processing... Please wait.") 
       date_val=request.POST['selday']
       current_date=date_val
       current_date1 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%d-%m-%Y")
       current_date2 = datetime.strptime(date_val, "%Y-%m-%d").strftime("%Y%m%d")
       print("date_value "+date_val+"current_date :"+current_date+" 1:"+current_date1+" 2:"+current_date2)

    cpl_sec_diff_file=os.path.join(settings.MAGDATA_ROOT,"cpl/cplvsec/cpl"+current_date2+"vsec.sec")
    hyb_sec_diff_file=os.path.join(settings.MAGDATA_ROOT,"hyb/hybvsec/hyb"+current_date2+"vsec.sec")

    div_err="<br><br><br><br>"

    # Check if the CPL file exists
    if os.path.exists(cpl_sec_diff_file):
       df_cpl=pd.read_fwf(cpl_sec_diff_file, skiprows=15 )
       df_cpl["Time period"] = pd.to_datetime(df_cpl['DATE'] + ' ' + df_cpl['TIME'])
       df_cpl.set_index('Time period', inplace=True)
       script2, div2=get_diff_plot(df_cpl,'CPL')
       fcpl=True
       len_cpl=df_cpl.shape[0]
    else:
       fcpl=False
       script2=""
       div2 =" <div class=\"alert alert-warning\"><strong>IMO_CPL :"+current_date1+" </strong> <br>  \
       <strong>Warning! Data Not Available.... </strong></center> </div>" 

    if os.path.exists(hyb_sec_diff_file):
       df_hyb=pd.read_fwf(hyb_sec_diff_file, skiprows=15 )
       df_hyb["Time period"] = pd.to_datetime(df_hyb['DATE'] + ' ' + df_hyb['TIME'])
       df_hyb.set_index('Time period', inplace=True)
       script1, div1=get_diff_plot(df_hyb,'HYB')
       fhyb=True
       len_hyb=df_hyb.shape[0]
    else:
       fhyb=False
       script1=""
       div1=" <div class=\"alert alert-warning\"><strong>IMO_HYB :"+current_date1+" </strong> <br>  \
        <strong>Warning! Data Not Available.... </strong></center> </div>" 
       
    # Pass the script and div to the template
    context={"script1": script1, "div1": div1,"script2": script2, "div2": div2,'today':current_date,'today1':current_date1}
    return render(request, "sec1diff.html", context)

@csrf_exempt
def check_status(request):
    """Check if the figure is ready."""
    return JsonResponse(figure_ready)

